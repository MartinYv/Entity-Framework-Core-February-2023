﻿namespace Theatre.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-8N6PVG5;Database=Theatre;Integrated Security=True;Encrypt=False";
    }
}
