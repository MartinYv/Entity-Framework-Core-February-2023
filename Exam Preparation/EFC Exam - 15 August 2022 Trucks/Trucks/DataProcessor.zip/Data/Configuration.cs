﻿namespace Trucks.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-8N6PVG5;Database=Trucks;Trusted_Connection=True";
    }
}