﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-8N6PVG5;Database=TeisterMaskExam;Integrated Security=True;Encrypt=False";
    }
}
