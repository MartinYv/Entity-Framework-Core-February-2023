﻿namespace Footballers.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-8N6PVG5;Database=FootballersExam;Trusted_Connection=True";
    }
}
