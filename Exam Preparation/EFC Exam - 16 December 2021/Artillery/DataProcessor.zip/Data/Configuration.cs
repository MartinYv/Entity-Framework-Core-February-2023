﻿namespace Artillery.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-8N6PVG5;Database=Artillery;Integrated Security=True;Encrypt=False";
    }
}
