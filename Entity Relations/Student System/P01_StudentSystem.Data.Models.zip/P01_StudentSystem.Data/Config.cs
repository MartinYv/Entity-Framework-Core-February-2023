﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_StudentSystem.Data
{
   public class Config
    {
        public const string ConnectionString = @"Server=DESKTOP-8N6PVG5;Database=Student System;IntegratedSecurity=True;";
    }
}
