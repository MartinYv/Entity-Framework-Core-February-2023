﻿namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-8N6PVG5;Database=CarDealer;Integrated Security=True;Encrypt=False";
    }
}
