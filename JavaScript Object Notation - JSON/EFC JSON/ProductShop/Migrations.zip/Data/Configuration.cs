﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-8N6PVG5;Database=ProductShop;Integrated Security=True";
    }
}
